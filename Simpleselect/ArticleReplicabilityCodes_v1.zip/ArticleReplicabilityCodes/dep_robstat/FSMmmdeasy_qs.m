function [mmd,Un,varargout] = FSMmmdeasy_qs(Y,bsb,varargin)
%FSMmmdeasy is exactly equal to FSMmmd but it is much less efficient
%
%<a href="matlab: docsearchFS('FSMmmdeasy')">Link to the help function</a>
%
% Required input arguments:
%
% Y :           Input data. Matrix.
%               n x v data matrix; n observations and v variables. Rows of
%               Y represent observations, and columns represent variables.
%               Missing values (NaN's) and infinite values (Inf's) are
%               allowed, since observations (rows) with missing or infinite
%               values will automatically be excluded from the
%               computations.
%                Data Types - single|double
% bsb :         Units forming subset. Vector. List of units forming the initial subset.
%               If bsb=0 (default) then the procedure starts with p units randomly
%               chosen else if bsb is not 0 the search will start with
%               m0=length(bsb)
%               Data Types - single | double
%
%
% Optional input arguments:
%
% init :       Point where to start monitoring required diagnostics. Scalar.
%              Note that if bsb is supplied, init>=length(bsb). If init is not
%              specified it will be set equal to floor(n*0.6).
%                 Example - 'init',50
%                 Data Types - double
%
% plots :     It specify whether it is necessary to produce the plots of minimum Mahalanobis
%                 distance. Scalar. If plots=1, a plot of the monitoring of minMD among
%               the units not belonging to the subset is produced on the
%               screen with 1% 50% and 99% confidence bands
%               else (default) no plot is produced.
%                 Example - 'plots',0
%                 Data Types - double
%
%  msg  :     It controls whether to display or not messages
%               about great interchange on the screen. Scalar.
%               If msg==1 (default) messages are displyed on the screen
%               else no message is displayed on the screen.
%                 Example - 'msg',0
%                 Data Types - double
%
% Remark:       The user should only give the input arguments that have to
%               change their default value.
%               The name of the input arguments needs to be followed by
%               their value. The order of the input arguments is of no
%               importance.
%
%               Missing values (NaN's) and infinite values (Inf's) are
%               allowed, since observations (rows) with missing or infinite
%               values will automatically be excluded from the
%               computations. y can be both a row of column vector.
%
% Output:
%
% mmd:          (n-init) x 2 matrix which contains the monitoring of minimum
%               Mahalanobis distance each step of the forward search.
%               1st col = fwd search index (from init to n-1).
%               2nd col = minimum Mahalanobis distance.
% Un:          (n-init) x 11 Matrix which contains the unit(s) included
%               in the subset at each step of the search.
%               REMARK: in every step the new subset is compared with the
%               old subset. Un contains the unit(s) present in the new
%               subset but not in the old one.
%               Un(1,2) for example contains the unit included in step
%               init+1.
%               Un(end,2) contains the units included in the final step
%               of the search.
%
%  Optional Output:
%
% BB :   n x (n-init+1) matrix containing units belonging to subset in
%               each step of the search. Each row is associated to a unit
%               while each colum is associated to a step of the fwd search.
%
% See also FSMenvmmd.m, FSM.m, FSMmmd
%
%
% References:
%
% Atkinson, A.C., Riani, M. and Cerioli, A. (2004), "Exploring multivariate
% data with the forward search", Springer Verlag, New York.
%
%
%
% Copyright 2008-2019.
% Written by FSDA team
%
%
%<a href="matlab: docsearchFS('FSMmmdeasy')">Link to the help function</a>
%
%$LastChangedDate::                      $: Date of the last commit


% Examples:

%{
    %% Minimum Mahalanobis distance.
    % Personalized initial subset (small n). Create an initial subset with
    % the 4 observations which fell the smallest
    % number of times outside the robust bivariate ellipses and with the
    % lowest Mahalanobis Distance.
    n=200;
    v=3;
    m0=4;
    randn('state',123456);
    Y=randn(n,v);
    %Contaminated data
    Ycont=Y;
    Ycont(1:5,:)=Ycont(1:5,:)+3;
    [fre]=unibiv(Y);
    fre=sortrows(fre,[3 4]);
    bs=fre(1:m0,1);
    randn('state',123456);
    mmd=FSMmmdeasy(Ycont,bs);
    randn('state',123456);
    mmd2=FSMmmdeasy_qs(Ycont,bs);
    randn('state',123456);
    mmd3=FSMmmdeasy_qs(Ycont,bs,'ostype','qs__');
    randn('state',123456);
    mmd4=FSMmmdeasy_qs(Ycont,bs,'ostype','qso_');
    randn('state',123456);
    mmd5=FSMmmdeasy_qs(Ycont,bs,'ostype','qsc_');
    plot(mmd(:,1),mmd(:,2)); hold on
    plot(mmd2(:,1),mmd2(:,2));
    plot(mmd3(:,1),mmd3(:,2));
    plot(mmd4(:,1),mmd4(:,2));
    plot(mmd5(:,1),mmd5(:,2));
%}

%{
    %% FSMmmdeasy with optional arguments.
    % Plotting the bandwith of the minimum Mahalanobis distance
    n=200;
    v=3;
    m0=4;
    randn('state',123456);
    Y=randn(n,v);
    %Contaminated data
    Ycont=Y;
    Ycont(1:5,:)=Ycont(1:5,:)+3;
    [fre]=unibiv(Y);
    fre=sortrows(fre,[3 4]);
    bs=fre(1:m0,1);
    [mmd]=FSMmmdeasy(Ycont,bs,'plots',1);
%}

%{
    % Checking the unit(s) included in the subset at each step of the
    % search.
    % Un contains the unit(s) present in the new subset but not in the old one.
    n=200;
    v=3;
    m0=4;
    randn('state',123456);
    Y=randn(n,v);
    %Contaminated data
    Ycont=Y;
    Ycont(1:5,:)=Ycont(1:5,:)+3;
    [fre]=unibiv(Y);
    fre=sortrows(fre,[3 4]);
    bs=fre(1:m0,1);
    [mmd,Un]=FSMmmdeasy(Ycont,bs,'plots',1);
%}

%{
    % Checking the units belonging to subset in each step of the search.
    % Personalized initial subset (large n). Each row of BB matrix
    % is associated to a unit while each colum is associated to a step of the fwd search.
    n=500;
    v=3;
    m0=10;
    randn('state',123456);
    Y=randn(n,v);
    % 25 per cent of Contaminated data
    Ycont=Y;
    Ycont(1:50,:)=Ycont(1:50,:)+3;
    [fre]=unibiv(Y);
    fre=sortrows(fre,[3 4]);
    bs=fre(1:m0,1);
    [mmd,Un,BB]=FSMmmdeasy(Ycont,bs,'plots',1);
%}


%% Beginning of code


[n,v]=size(Y);
% Initialize matrix which will contain Mahalanobis distances in each step
seq=(1:n)';

%% Input parameters checking

hdef=floor(n*0.6);

options=struct('ostype','sort','init',hdef,'plots',0,'msg',1);

if nargin<2
    error('FSDA:FSMmmdeasy:missingInputs','Initial subset is missing')
end

UserOptions=varargin(1:2:length(varargin));
if ~isempty(UserOptions)
    % Check if number of supplied options is valid
    if length(varargin) ~= 2*length(UserOptions)
        error('FSDA:FSMmmdeasy:WrongInputOpt','Number of supplied options is invalid. Probably values for some parameters are missing.');
    end
    % Check if user options are valid options
    chkoptions(options,UserOptions)
end

%init1=options.init;
if nargin > 2
    % Write in structure 'options' the options chosen by the user
    for i=1:2:length(varargin)
        options.(varargin{i})=varargin{i+1};
    end
end

% GET THE ORDER STATISTICS TYPE CHOSEN BY THE USER
ostype = options.ostype;

% And check if the optional user parameters are reasonable.

if bsb==0
    Ra=1; nwhile=1;
    while and(Ra,nwhile<100)
        % Extract a random sample of size v+1
        bsb=randsample(n,v+1);
        % Check if the var-cov matrix of the random sample is full (i.e =v)
        Ra=(rank(cov(Y(bsb,:)))<v);
        nwhile=nwhile+1;
    end
    if nwhile==100
        warning('FSDA:FSMmmdeasy:NoFullRank','Unable to randomly sample full rank matrix');
    end
else
end


ini0=length(bsb);

% check init
init1=options.init;
msg=options.msg;

if  init1 <v+1
    mess=sprintf(['Attention : init1 should be larger than v. \n',...
        'It is set to v+1.']);
    fprintf('%s\n',mess);
    init1=v+1;
elseif init1<ini0
    mess=sprintf(['Attention : init1 should be >= length of supplied subset. \n',...
        'It is set equal to ' num2str(length(bsb)) ]);
    fprintf('%s\n',mess);
    init1=ini0;
elseif init1>=n
    mess=sprintf(['Attention : init1 should be smaller than n. \n',...
        'It is set to n-1.']);
    fprintf('%s\n',mess);
    init1=n-1;
end


if nargout>=3 && n<5000
    % Initialize matrix which will contain the units forming subset in each
    % step of the fwd search
    BB=NaN(n,n-init1+1,'single');
end


%  Un is a Matrix whose 2nd column:11th col contains the unit(s) just
%  included.
Un = cat(2 , (init1+1:n)' , NaN(n-init1,10));

%  mmd has two columns
%  1st col = dimension of the subset
%  2nd col min. Mahalanobis distances among the units
%  which do not belong to the subset
mmd=[(init1:n-1)' zeros(n-init1,1)];

mala=[seq zeros(n,1)];

if (rank(Y(bsb,:))<v)
    warning('FSDA:FSMmmdeasy:NoFullRank','The supplied initial subset is not full rank matrix');
    disp('FS loop will not be performed')
    mmd=NaN;
    Un=NaN;
    varargout={NaN};
    % FS loop will not be performed
else
    tend = zeros(n-ini0,1);
    for mm = ini0:n
        % select subset
        Yb=Y(bsb,:);
        
        if (mm>=init1) && nargout==3
            BB(bsb,mm-init1+1)=bsb;
        end
        
        % Find vector of means inside subset
        % Note that ym is a row vector
        ym=mean(Yb);
        
        % Squared Mahalanobis distances computed using QR decomposition
        % Ym=Y-one*ym;
        Ym = bsxfun(@minus,Y, ym);
        
        [~,R]=qr(Ym(bsb,:),0);
        
        
        % Remark: u=(Ym/R)' should be much faster than u=inv(R')*Ym';
        u=(Ym/R)';
        
        % Compute square Mahalanobis distances
        mala(:,2)=((mm-1)*sum(u.^2,1))';
        
        if mm<n
            
            mala_tmp = mala(:,2);
            mala_tmp(bsb) = inf;
            [minMD,minMDindex] = min(mala_tmp);
            
            % mmd contains minimum of Mahalanobis distances among
            % the units which form the group of potential outliers
            if (mm>=init1)
                
                mmd(mm-init1+1,2)  = sqrt(minMD);
                %ncl=setdiff(seq,bsb);
                %sncl=sortrows(mala(ncl,2));
                %mmd(mm-init1+1,2)=sqrt(sncl(1));                
            end
            
            % store units forming old subset in vector oldbsb
            oldbsb=bsb;
            
            % the dimension of subset increases by one unit.
            % vector bsb contains the indexes corresponding to the units of
            % the new subset
            MD = mala(:,2);
            switch ostype
                case 'sort'
                    t = tic;
                    %zs = sortrows(mala,2);
                    [~ , zsi] = sort(MD);
                    zs        = mala(zsi , :);
                    bsb=zs(1:mm+1,1);
                    tend(mm-ini0+1) = toc(t);
                    
                case 'qs__'
                    t = tic;
                    % New sorting based on quickselectFS
                    %[ksor]=quickselectFS(MD,mm+1);
                    %bsb=MD<=ksor;
                    bsb=find(MD-quickselectFS(MD,mm+1)<=0);
                    tend(mm-ini0+1) = toc(t);
                case 'qso_'
                    t = tic;
                    % New sorting based on quickselectFS with oracle
                    %[ksor]=quickselectFS(MD,mm+1,minMDindex);
                    %bsb=MD<=ksor;
                    bsb=find(MD-quickselectFS(MD,mm+1,minMDindex)<=0);
                    tend(mm-ini0+1) = toc(t);
                case 'qsc_'
                    t = tic;
                    % New sorting based on compiled quickselectFS
                    maha1 = MD(1); mdtmp = MD; mdtmp(1)=maha1;
                    %SIMPLEselect(mdtmp,n,mm);    %remark: mm instead of mm+1
                    quickselectFSmex(mdtmp,n,mm); %remark: mm instead of mm+1
                    bsb=find(MD-mdtmp(mm+1)<=0);
                    %ksor = mdtmp(mm+1);
                    %bsb=MD<=ksor;
                    tend(mm-ini0+1) = toc(t);
                case 'qsoc'
                    % New sorting based on compiled quickselectFS with
                    % oracle
                    % TO BE DONE IN C (not yet implemented)
                case 'nrc_'
                    t = tic;
                    % New sorting based on compiled quickselect from
                    % Numerical Recipes in C
                    maha1 = MD(1); mdtmp = MD; mdtmp(1)=maha1;
                    NUREselect(mdtmp,n,mm); %remark: mm instead of mm+1
                    %ksor = mdtmp(mm+1);
                    %bsb=MD<=ksor;
                    bsb=find(MD-mdtmp(mm+1)<=0);
                    tend(mm-ini0+1) = toc(t);
            end
            
            
            if (mm>=init1)
                %unit0=setdiff(bsb,oldbsb); % setdiff is slow: replaced
                unit = unique(bsb(~(ismember(bsb(:),oldbsb(:)))),'stable');
                %if sum(unit0-unit)>0,disp('zob');end
                if (length(unit)<=10)
                    Un(mm-init1+1,2:(length(unit)+1))=unit;
                else
                    if msg==1
                        disp(['Warning: interchange greater than 10 when m=' int2str(mm)]);
                        disp(['Number of units which entered=' int2str(length(unit))]);
                    end
                    Un(mm-init1+1,2:end)=unit(1:10);
                end
            end
        else
        end
        
        if nargout==3  || (nargout==4 && ~isempty(BB))
            varargout={BB};
        end
        
        % Plot minimum Mahalanobis distance with 1%, 50% and 99% envelopes
        if options.plots==1
            quant=[0.01;0.5;0.99];
            % Compute theoretical envelops for minimum Mahalanobis distance based on all
            % the observations for the above quantiles.
            [gmin] = FSMenvmmd(n,v,'prob',quant,'init',init1);
            plot(mmd(:,1),mmd(:,2));
            
            % Superimpose 1%, 99%, 99.9% envelopes based on all the observations
            lwdenv=2;
            % Superimpose 50% envelope
            line(gmin(:,1),gmin(:,3),'LineWidth',lwdenv,'LineStyle','--','Color','g','tag','env');
            % Superimpose 1% and 99% envelope
            line(gmin(:,1),gmin(:,2),'LineWidth',lwdenv,'LineStyle','--','Color',[0.2 0.8 0.4],'tag','env');
            line(gmin(:,1),gmin(:,4),'LineWidth',lwdenv,'LineStyle','--','Color',[0.2 0.8 0.4],'tag','env');
            
            xlabel('Subset size m');
            ylabel('Monitoring of minimum Mahalanobis distance');
        end
        
    end
end
if nargout==3 || (nargout==4 && ~isempty(BB))
    varargout(1)={BB};
end
if nargout==4
    varargout(2)={[median(tend) , mad(tend) , sum(tend>0)]};
end
end

%FScategory:MULT-Multivariate
